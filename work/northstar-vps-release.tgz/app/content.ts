export const site = {
  name: "北辰笔记",
  description:
    "一个更克制的中文个人博客，写随笔、短记和那些没有立刻消失的念头。",
  url: "http://blog.jiecaisongai.shop",
};

export type PostKind = "essay" | "diary";

export type Post = {
  slug: string;
  kind: PostKind;
  category: string;
  title: string;
  summary: string;
  date: string;
  readTime: string;
  kicker: string;
  body: string[];
  featured?: boolean;
};

export const posts: Post[] = [
  {
    slug: "homepage-should-breathe",
    kind: "essay",
    category: "写作与界面",
    title: "我想把首页做得安静一点，不再像一张急着证明自己的海报",
    summary:
      "一个好的博客首页，不需要摆满功能。它更像一扇门，只负责让人愿意往里走一步。",
    date: "2026 年 6 月 11 日",
    readTime: "8 分钟",
    kicker: "主文章",
    featured: true,
    body: [
      "很多博客不是没有内容，而是太着急解释自己。标题、按钮、标签、模块同时抢注意力，结果真正应该被读的句子，反而成了页面里最弱的一层。",
      "所以这次重做，我不想继续把首页做成一个功能看板。我更想让它像一本笔记的扉页，打开之后先感受到气氛，再慢慢进入正文。",
      "安静不是空，也不是冷淡。它更像一种克制：知道哪些东西该出现，哪些东西应该退后。真正值得留下来的，不是页面里塞进了多少模块，而是读者是否愿意看完第二段、第三段，甚至几天后再回来。"
    ]
  },
  {
    slug: "quiet-can-still-be-expensive",
    kind: "essay",
    category: "版式观察",
    title: "安静的页面，也可以看起来很贵",
    summary:
      "真正撑起气质的，往往不是装饰，而是留白、节奏和标题之间那一点恰到好处的克制。",
    date: "2026 年 6 月 9 日",
    readTime: "5 分钟",
    kicker: "最近文章",
    body: [
      "很多页面做得热闹，但不高级。原因通常不是颜色不对，而是每个元素都在大声说话。视觉上没有主次，阅读上也就没有节奏。",
      "相反，一些真正耐看的页面往往非常安静。标题强，留白足，信息密度控制得刚刚好，于是读者会自然地知道自己该先看哪里，再看哪里。",
      "这种感觉很难靠模板直接复制出来，它更像排版上的判断力。什么时候该停，什么时候该让开，什么时候只说一句就够。"
    ]
  },
  {
    slug: "trust-is-built-quietly",
    kind: "essay",
    category: "站点结构",
    title: "一个让人信任的个人网站，很多时候靠的都是安静工程",
    summary:
      "稳定、清楚、可预期，这些不太显眼的东西，反而决定了别人会不会把这个网址留下来。",
    date: "2026 年 6 月 4 日",
    readTime: "6 分钟",
    kicker: "最近文章",
    body: [
      "很多人会先注意一个网站长什么样，但决定它能不能留下来的，往往是另外一些更安静的东西：它是不是总能打开，手机上会不会乱，文章页是不是读起来顺手。",
      "这些都不算炫耀点，却几乎构成了一个站最核心的可信度。你不用特意解释自己有多认真，页面本身会替你说明。",
      "个人博客尤其如此。它没有大团队、没有品牌背书，很多时候，它就只能靠这些细节证明自己不是临时搭起来的。"
    ]
  },
  {
    slug: "archive-needs-a-future",
    kind: "essay",
    category: "更新方法",
    title: "归档不只是整理旧文，它还应该提前暗示未来会继续写下去",
    summary:
      "一个能让人持续更新的博客，应该在第一天就看起来像有第二天。",
    date: "2026 年 5 月 28 日",
    readTime: "5 分钟",
    kicker: "最近文章",
    body: [
      "孤零零的一篇文章并不丢人，很多博客都是这样开始的。真正让人停下来的，是作者自己都觉得这个地方还不像一个会继续生长的站点。",
      "所以归档的意义，不只是把旧东西收起来。它也在暗示：这里以后还会多出新的页、新的句子、新的日期。",
      "当一个博客从第一天起就带着这种未来感，更新会变得自然很多。你不会觉得每次发文都是从零开始。"
    ]
  },
  {
    slug: "no-story-in-my-head",
    kind: "diary",
    category: "日记摘页",
    title: "我的脑海里没有故事",
    summary:
      "我想写些什么；一些故事，一种人，或者一种柑橘。虚构的最好，但是我的脑海里没有故事。",
    date: "2026 年 5 月 28 日",
    readTime: "2 分钟",
    kicker: "摘页",
    body: [
      "我想写些什么；一些故事，一种人，或者一种柑橘。",
      "虚构的最好，但是我的脑海里没有故事。",
      "有时候不是没有表达欲，而是没有一个合适的入口。句子明明在门后面，却迟迟不肯出来。"
    ]
  },
  {
    slug: "operating-system-is-boring",
    kind: "diary",
    category: "日记摘页",
    title: "操作系统好枯燥呀",
    summary: "真的。",
    date: "2026 年 5 月 19 日",
    readTime: "1 分钟",
    kicker: "摘页",
    body: [
      "操作系统好枯燥呀。",
      "真的。",
      "有些记录短得像一个叹气，但回头看时，反而最能把当时的状态留住。"
    ]
  },
  {
    slug: "not-a-person-without-desire",
    kind: "diary",
    category: "日记摘页",
    title: "好想摆烂，但我又不是一个无欲的人",
    summary:
      "我想做的事情很多，喜欢的东西也不少。不只是欲望多，而是新的念头总会不断浮现出来。",
    date: "2026 年 5 月 17 日",
    readTime: "3 分钟",
    kicker: "摘页",
    body: [
      "好想摆烂。",
      "可是我发现我不是一个无欲的人。我想做的事情很多，喜欢的东西也不少。",
      "最麻烦的地方不是累，而是明明想停下，却总有新的念头又冒出来。"
    ]
  },
  {
    slug: "emotion-was-only-archived",
    kind: "diary",
    category: "日记摘页",
    title: "也许情绪不是消失了，只是被存档了",
    summary:
      "有些看似理性的分析，也可能只是回避情绪的方式。感受、理解、表达，最后让它挥发掉，也许才算真的处理。",
    date: "2026 年 4 月 1 日",
    readTime: "4 分钟",
    kicker: "摘页",
    body: [
      "有些看似冷静的分析，也许并不是真的理解了情绪，而只是把它压缩、存档，不再提起。",
      "但没有被处理掉的东西，并不会真的消失。它只是换了一种形式停在身体里，等着下一次被碰到。",
      "所以感受情绪、理解情绪、表达情绪，本身就是一种处理，而不是软弱。"
    ]
  }
];

export const featuredPost = posts.find((post) => post.featured)!;
export const essayPosts = posts.filter((post) => post.kind === "essay");
export const diaryPosts = posts.filter((post) => post.kind === "diary");

export function getPost(slug: string) {
  return posts.find((post) => post.slug === slug);
}

export function getAdjacentPosts(slug: string) {
  const index = posts.findIndex((post) => post.slug === slug);

  return {
    previous: index > 0 ? posts[index - 1] : null,
    next: index >= 0 && index < posts.length - 1 ? posts[index + 1] : null,
  };
}
