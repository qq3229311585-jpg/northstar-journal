import Link from "next/link";
import { diaryPosts } from "../content";

export default function DiaryPage() {
  return (
    <main className="shell list-page">
      <div className="page-intro">
        <p className="section-kicker">日记摘页</p>
        <h1 className="page-title">不完整也没关系，有些句子本来就只适合以片段的方式留下来。</h1>
      </div>

      <div className="diary-stack">
        {diaryPosts.map((post) => (
          <Link href={`/posts/${post.slug}`} key={post.slug} className="diary-row">
            <div className="diary-row-meta">
              <span>{post.kicker}</span>
              <span>{post.date}</span>
            </div>
            <div className="diary-row-main">
              <h2>{post.title}</h2>
              <p>{post.summary}</p>
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
