import type { Metadata } from "next";
import Link from "next/link";
import { Fraunces, IBM_Plex_Mono, Manrope } from "next/font/google";
import { site } from "./content";
import "./globals.css";

const displayFont = Fraunces({
  variable: "--font-display",
  subsets: ["latin"],
});

const bodyFont = Manrope({
  variable: "--font-body",
  subsets: ["latin"],
});

const monoFont = IBM_Plex_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: site.name,
    template: `%s | ${site.name}`,
  },
  description: site.description,
  alternates: {
    canonical: "/",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  openGraph: {
    title: site.name,
    description: site.description,
    url: site.url,
    siteName: site.name,
    type: "website",
    locale: "zh_CN",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body
        className={`${displayFont.variable} ${bodyFont.variable} ${monoFont.variable}`}
      >
        <div className="site-frame">
          <header className="site-header">
            <div className="shell header-shell">
              <Link href="/" className="brand">
                <span className="brand-title">{site.name}</span>
                <span className="brand-sub">Quiet Notes For Restless Days</span>
              </Link>

              <nav className="site-nav" aria-label="主导航">
                <Link href="/writing">文章</Link>
                <Link href="/diary">摘页</Link>
                <Link href="/about">关于</Link>
              </nav>
            </div>
          </header>

          {children}

          <footer className="site-footer">
            <div className="shell footer-shell">
              <div>
                <p className="footer-title">{site.name}</p>
                <p className="footer-text">
                  一个更克制的中文博客，写随笔、短记和那些没有立刻消失的念头。
                </p>
              </div>

              <div className="footer-links">
                <Link href="/writing">全部文章</Link>
                <Link href="/diary">日记摘页</Link>
                <Link href="/about">站点说明</Link>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
