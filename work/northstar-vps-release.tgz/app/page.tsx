import Link from "next/link";
import { diaryPosts, essayPosts, featuredPost } from "./content";

const homeNotes = [
  "首页不再堆卡片，而是让信息有前后顺序。",
  "正文页、摘页页和关于页共用同一套视觉节奏。",
  "每篇内容都能点进去，不再只是停在展示层。",
];

export default function Home() {
  return (
    <main className="shell home-shell">
      <section className="masthead">
        <div className="masthead-topline">
          <span>中文个人博客</span>
          <span>第 01 版</span>
        </div>

        <div className="masthead-grid">
          <div>
            <p className="section-kicker">首页改版</p>
            <h1 className="masthead-title">
              做一个更安静的站，
              <span>让句子比界面更先被记住。</span>
            </h1>
          </div>

          <div className="masthead-side">
            <p>
              这次不追求模板感，也不追求把功能堆满。它更像一本会继续被写下去的笔记，
              首页负责留下气氛，正文负责把句子接住。
            </p>

            <div className="action-row">
              <Link href={`/posts/${featuredPost.slug}`} className="solid-link">
                进入主文章
              </Link>
              <Link href="/writing" className="ghost-link">
                查看全部文章
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="feature-band">
        <div className="feature-copy">
          <p className="section-kicker">{featuredPost.kicker}</p>
          <Link href={`/posts/${featuredPost.slug}`} className="feature-link">
            <h2>{featuredPost.title}</h2>
            <p>{featuredPost.summary}</p>
          </Link>
        </div>

        <ul className="note-list">
          {homeNotes.map((note) => (
            <li key={note}>{note}</li>
          ))}
        </ul>
      </section>

      <section className="list-section">
        <div className="section-heading-row">
          <div>
            <p className="section-kicker">文章</p>
            <h2 className="section-title">像目录一样安静，也像目录一样清楚。</h2>
          </div>
          <Link href="/writing" className="text-link">
            全部文章
          </Link>
        </div>

        <div className="editorial-list">
          {essayPosts.map((post, index) => (
            <Link href={`/posts/${post.slug}`} key={post.slug} className="list-row">
              <div className="row-index">{String(index + 1).padStart(2, "0")}</div>
              <div className="row-main">
                <p className="row-meta">
                  <span>{post.category}</span>
                  <span>{post.date}</span>
                </p>
                <h3>{post.title}</h3>
              </div>
              <p className="row-summary">{post.summary}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="diary-section-v2">
        <div className="section-heading-row">
          <div>
            <p className="section-kicker">摘页</p>
            <h2 className="section-title">保留一些未经修饰的记录，让网站不只是一个门面。</h2>
          </div>
          <Link href="/diary" className="text-link">
            更多摘页
          </Link>
        </div>

        <div className="diary-stack">
          {diaryPosts.map((post) => (
            <Link href={`/posts/${post.slug}`} key={post.slug} className="diary-row">
              <div className="diary-row-meta">
                <span>{post.kicker}</span>
                <span>{post.date}</span>
              </div>
              <div className="diary-row-main">
                <h3>{post.title}</h3>
                <p>{post.summary}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
