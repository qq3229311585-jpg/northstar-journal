import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getAdjacentPosts, getPost, posts } from "../../content";

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = getPost(slug);

  if (!post) {
    return { title: "文章未找到" };
  }

  return {
    title: post.title,
    description: post.summary,
    alternates: {
      canonical: `/posts/${post.slug}`,
    },
  };
}

export default async function PostPage({ params }: Props) {
  const { slug } = await params;
  const post = getPost(slug);

  if (!post) {
    notFound();
  }

  const { previous, next } = getAdjacentPosts(post.slug);

  return (
    <main className="shell article-shell-v2">
      <Link href="/writing" className="back-link">
        返回文章列表
      </Link>

      <article className="article-layout">
        <aside className="article-rail">
          <p>{post.kicker}</p>
          <p>{post.category}</p>
          <p>{post.date}</p>
          <p>{post.readTime}</p>
        </aside>

        <div className="article-content">
          <header className="article-header">
            <h1>{post.title}</h1>
            <p className="article-summary">{post.summary}</p>
          </header>

          <div className="article-prose">
            {post.body.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>

          <nav className="article-pager" aria-label="文章切换">
            <div>
              <span className="pager-label">上一篇</span>
              {previous ? (
                <Link href={`/posts/${previous.slug}`}>{previous.title}</Link>
              ) : (
                <span className="pager-empty">已经是第一篇</span>
              )}
            </div>

            <div>
              <span className="pager-label">下一篇</span>
              {next ? (
                <Link href={`/posts/${next.slug}`}>{next.title}</Link>
              ) : (
                <span className="pager-empty">已经是最后一篇</span>
              )}
            </div>
          </nav>
        </div>
      </article>
    </main>
  );
}
