import Link from "next/link";
import { essayPosts } from "../content";

export default function WritingPage() {
  return (
    <main className="shell list-page">
      <div className="page-intro">
        <p className="section-kicker">全部文章</p>
        <h1 className="page-title">把完整的文章收在这里，像一份慢慢变厚的目录。</h1>
      </div>

      <div className="editorial-list">
        {essayPosts.map((post, index) => (
          <Link href={`/posts/${post.slug}`} key={post.slug} className="list-row">
            <div className="row-index">{String(index + 1).padStart(2, "0")}</div>
            <div className="row-main">
              <p className="row-meta">
                <span>{post.category}</span>
                <span>{post.date}</span>
              </p>
              <h2>{post.title}</h2>
            </div>
            <p className="row-summary">{post.summary}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
